"use client"

import { useState, useMemo, Fragment } from "react"
import { Search, ChevronDown, Lock, X, Plus, Trash2, Edit2, Check } from "lucide-react"

const ADMIN_PASSWORD = "Atlas@Dev2024#S"

type Command = {
  id: string
  name: string
  description: string
}

type Category = {
  id: string
  name: string
  description: string
  count: number
  commands: Command[]
}

const initialCategories: Category[] = [
  {
    id: "general",
    name: "General",
    description: "Basic bot commands and information",
    count: 9,
    commands: [
      { id: "g1", name: "help", description: "Shows all commands and categories" },
      { id: "g2", name: "h", description: "Alias for help command" },
      { id: "g3", name: "ping", description: "Check bot latency" },
      { id: "g4", name: "stats", description: "View bot statistics" },
      { id: "g5", name: "botinfo", description: "Detailed bot information" },
      { id: "g6", name: "uptime", description: "Check how long bot has been online" },
      { id: "g7", name: "invite", description: "Get bot invite link" },
      { id: "g8", name: "support", description: "Get support server link" },
      { id: "g9", name: "vote", description: "Vote for the bot" },
    ],
  },
  {
    id: "moderation",
    name: "Moderation",
    description: "Ban, kick, mute, lock, purge & full server management",
    count: 26,
    commands: [
      { id: "m1", name: "ban", description: "Ban a user from the server" },
      { id: "m2", name: "softban", description: "Ban and immediately unban to clear messages" },
      { id: "m3", name: "kick", description: "Kick a user from the server" },
      { id: "m4", name: "mute", description: "Mute a user" },
      { id: "m5", name: "unmute", description: "Unmute a user" },
      { id: "m6", name: "unban", description: "Unban a user" },
      { id: "m7", name: "unbanall", description: "Unban all users" },
      { id: "m8", name: "warn", description: "Warn a user" },
      { id: "m9", name: "nick", description: "Change user nickname" },
      { id: "m10", name: "nickname", description: "Alias for nick command" },
      { id: "m11", name: "lock", description: "Lock a channel" },
      { id: "m12", name: "lockch", description: "Lock specific channel" },
      { id: "m13", name: "unlock", description: "Unlock a channel" },
      { id: "m14", name: "unlockch", description: "Unlock specific channel" },
      { id: "m15", name: "lockall", description: "Lock all channels" },
      { id: "m16", name: "unlockall", description: "Unlock all channels" },
      { id: "m17", name: "hide", description: "Hide a channel" },
      { id: "m18", name: "unhide", description: "Unhide a channel" },
      { id: "m19", name: "hideall", description: "Hide all channels" },
      { id: "m20", name: "unhideall", description: "Unhide all channels" },
      { id: "m21", name: "slowmode", description: "Set channel slowmode" },
      { id: "m22", name: "slow", description: "Alias for slowmode" },
      { id: "m23", name: "purge", description: "Delete multiple messages" },
      { id: "m24", name: "clear", description: "Clear messages" },
      { id: "m25", name: "prune", description: "Prune messages" },
      { id: "m26", name: "snipe", description: "View recently deleted message" },
    ],
  },
  {
    id: "antinuke",
    name: "AntiNuke",
    description: "Advanced nuke protection, whitelist, and detection logs",
    count: 10,
    commands: [
      { id: "an1", name: "antinuke", description: "View antinuke settings" },
      { id: "an2", name: "antinuke enable", description: "Enable antinuke protection" },
      { id: "an3", name: "antinuke disable", description: "Disable antinuke protection" },
      { id: "an4", name: "antinuke whitelist @user", description: "Whitelist a user from antinuke" },
      { id: "an5", name: "antinuke unwhitelist @user", description: "Remove user from whitelist" },
      { id: "an6", name: "antinuke logs", description: "View antinuke logs" },
      { id: "an7", name: "antinukelogs [#ch]", description: "Set antinuke log channel" },
      { id: "an8", name: "extraowner set @user", description: "Set extra owner" },
      { id: "an9", name: "extraowner reset @user", description: "Reset extra owner" },
      { id: "an10", name: "extraowner view", description: "View extra owners" },
    ],
  },
  {
    id: "automod",
    name: "AutoMod",
    description: "Auto-filter bad words, links, spam & mass mentions",
    count: 7,
    commands: [
      { id: "am1", name: "automod enable", description: "Enable automod" },
      { id: "am2", name: "automod disable", description: "Disable automod" },
      { id: "am3", name: "automod config", description: "View automod configuration" },
      { id: "am4", name: "automod punishment", description: "Set automod punishment" },
      { id: "am5", name: "automod ignore channel #ch", description: "Ignore a channel" },
      { id: "am6", name: "automod ignore role @role", description: "Ignore a role" },
      { id: "am7", name: "automod ignore show", description: "Show ignored channels/roles" },
    ],
  },
  {
    id: "utility",
    name: "Utility",
    description: "Avatar, server info, user info, giveaways & more",
    count: 11,
    commands: [
      { id: "u1", name: "avatar [@user]", description: "View user avatar" },
      { id: "u2", name: "serverinfo", description: "View server information" },
      { id: "u3", name: "userinfo [@user]", description: "View user information" },
      { id: "u4", name: "ui [@user]", description: "Alias for userinfo" },
      { id: "u5", name: "steal <emoji>", description: "Steal an emoji" },
      { id: "u6", name: "giveaway", description: "Create a giveaway" },
      { id: "u7", name: "afk [reason]", description: "Set AFK status" },
      { id: "u8", name: "banner [@user]", description: "View user banner" },
      { id: "u9", name: "users", description: "View server user count" },
      { id: "u10", name: "setprefix <prefix>", description: "Set bot prefix" },
      { id: "u11", name: "resetprefix", description: "Reset prefix to default" },
    ],
  },
  {
    id: "roles",
    name: "Roles",
    description: "Create, edit, list & manage server roles",
    count: 5,
    commands: [
      { id: "r1", name: "roles selection @R1 @R2", description: "Create role selection" },
      { id: "r2", name: "rolecreate <name> [color]", description: "Create a new role" },
      { id: "r3", name: "roleinfo <role>", description: "View role information" },
      { id: "r4", name: "rolelist", description: "List all roles" },
      { id: "r5", name: "roleedit <role> name|color|hoist <val>", description: "Edit a role" },
    ],
  },
  {
    id: "customroles",
    name: "CustomRoles",
    description: "Self-assignable roles - staff, VIP, friend, guest & more",
    count: 13,
    commands: [
      { id: "cr1", name: "setup", description: "Setup custom roles" },
      { id: "cr2", name: "setup staff @role", description: "Set staff role" },
      { id: "cr3", name: "setup vip @role", description: "Set VIP role" },
      { id: "cr4", name: "setup friend @role", description: "Set friend role" },
      { id: "cr5", name: "setup girl @role", description: "Set girl role" },
      { id: "cr6", name: "setup guest @role", description: "Set guest role" },
      { id: "cr7", name: "setup list", description: "List role setup" },
      { id: "cr8", name: "setup reset", description: "Reset role setup" },
      { id: "cr9", name: "staff", description: "Give staff role" },
      { id: "cr10", name: "vip", description: "Give VIP role" },
      { id: "cr11", name: "friend", description: "Give friend role" },
      { id: "cr12", name: "girl", description: "Give girl role" },
      { id: "cr13", name: "guest", description: "Give guest role" },
    ],
  },
  {
    id: "tracker",
    name: "Tracker",
    description: "Invite & message tracking - reward active members",
    count: 14,
    commands: [
      { id: "t1", name: "tracker", description: "View tracker settings" },
      { id: "t2", name: "messages [@user]", description: "View message count" },
      { id: "t3", name: "addmessages @user <n>", description: "Add messages to user" },
      { id: "t4", name: "removemessages @user <n>", description: "Remove messages from user" },
      { id: "t5", name: "clearmessages [all|@user]", description: "Clear message count" },
      { id: "t6", name: "resetmymessages", description: "Reset your message count" },
      { id: "t7", name: "invites [@user]", description: "View invite count" },
      { id: "t8", name: "inviter [@user]", description: "View who invited user" },
      { id: "t9", name: "invited [@user]", description: "View users invited by someone" },
      { id: "t10", name: "addinvites @user <n>", description: "Add invites to user" },
      { id: "t11", name: "removeinvites @user <n>", description: "Remove invites from user" },
      { id: "t12", name: "blacklistchannel [#ch]", description: "Blacklist a channel" },
      { id: "t13", name: "unblacklistchannel [#ch|all]", description: "Unblacklist a channel" },
      { id: "t14", name: "blacklistedchannels", description: "View blacklisted channels" },
    ],
  },
  {
    id: "logging",
    name: "Logging",
    description: "Log bans, joins, deletes, voice changes & more",
    count: 11,
    commands: [
      { id: "l1", name: "logging", description: "View logging settings" },
      { id: "l2", name: "logging setup #channel", description: "Set logging channel" },
      { id: "l3", name: "logging setup auto", description: "Auto-setup logging" },
      { id: "l4", name: "logging setup channel <event> #ch", description: "Set event channel" },
      { id: "l5", name: "logging setup clear", description: "Clear logging setup" },
      { id: "l6", name: "logging enable", description: "Enable logging" },
      { id: "l7", name: "logging disable", description: "Disable logging" },
      { id: "l8", name: "logging remove", description: "Remove logging" },
      { id: "l9", name: "logging ignore channel #ch", description: "Ignore a channel" },
      { id: "l10", name: "logging ignore user @user", description: "Ignore a user" },
      { id: "l11", name: "logging ignore role @role", description: "Ignore a role" },
    ],
  },
  {
    id: "embed",
    name: "Embed",
    description: "Build custom embeds for your server",
    count: 3,
    commands: [
      { id: "e1", name: "embed create", description: "Create a new embed" },
      { id: "e2", name: "embed new", description: "Create new embed" },
      { id: "e3", name: "embed list", description: "List all embeds" },
    ],
  },
  {
    id: "social",
    name: "Social",
    description: "Reminders, translation, calculators & social tools",
    count: 5,
    commands: [
      { id: "s1", name: "remind <time> [msg]", description: "Set a reminder" },
      { id: "s2", name: "remind list", description: "List your reminders" },
      { id: "s3", name: "translate <lang> <text>", description: "Translate text" },
      { id: "s4", name: "languages", description: "List supported languages" },
      { id: "s5", name: "calc <expression>", description: "Calculator" },
    ],
  },
  {
    id: "welcome",
    name: "Welcome",
    description: "Welcome and goodbye messages for new members",
    count: 6,
    commands: [
      { id: "w1", name: "greet setup", description: "Setup welcome messages" },
      { id: "w2", name: "greet reset", description: "Reset welcome settings" },
      { id: "w3", name: "greet channel", description: "Set welcome channel" },
      { id: "w4", name: "greet edit", description: "Edit welcome message" },
      { id: "w5", name: "greet test", description: "Test welcome message" },
      { id: "w6", name: "greet config", description: "View welcome config" },
    ],
  },
  {
    id: "fun",
    name: "Fun",
    description: "Memes, GIFs, ship calculator, truth or dare & more",
    count: 18,
    commands: [
      { id: "f1", name: "kiss @user", description: "Kiss someone" },
      { id: "f2", name: "hug @user", description: "Hug someone" },
      { id: "f3", name: "slap @user", description: "Slap someone" },
      { id: "f4", name: "cuddle @user", description: "Cuddle someone" },
      { id: "f5", name: "tickle @user", description: "Tickle someone" },
      { id: "f6", name: "punch @user", description: "Punch someone" },
      { id: "f7", name: "ship [@u1] [@u2]", description: "Ship two users" },
      { id: "f8", name: "truth", description: "Get a truth question" },
      { id: "f9", name: "dare", description: "Get a dare" },
      { id: "f10", name: "howgay [@user]", description: "How gay is someone" },
      { id: "f11", name: "gay [@user]", description: "Gay percentage" },
      { id: "f12", name: "intelligence [@user]", description: "Intelligence test" },
      { id: "f13", name: "iq [@user]", description: "IQ test" },
      { id: "f14", name: "smart [@user]", description: "Smart test" },
      { id: "f15", name: "meme [text]", description: "Generate a meme" },
      { id: "f16", name: "randommeme [text]", description: "Random meme" },
      { id: "f17", name: "mydog @user", description: "Mydog command" },
      { id: "f18", name: "dogmode @user", description: "Toggle dogmode" },
    ],
  },
  {
    id: "games",
    name: "Games",
    description: "Quiz, Tic Tac Toe, Chess - solo or multiplayer",
    count: 9,
    commands: [
      { id: "gm1", name: "guess", description: "Number guessing game" },
      { id: "gm2", name: "quiz", description: "Take a quiz" },
      { id: "gm3", name: "trivia", description: "Trivia game" },
      { id: "gm4", name: "tictactoe @user", description: "Play Tic Tac Toe" },
      { id: "gm5", name: "ttt @user", description: "Alias for tictactoe" },
      { id: "gm6", name: "ttt3 @user", description: "3x3 Tic Tac Toe" },
      { id: "gm7", name: "tictoe @user", description: "Alias for tictactoe" },
      { id: "gm8", name: "chess @user", description: "Play chess" },
      { id: "gm9", name: "chessgame @user", description: "Start chess game" },
    ],
  },
  {
    id: "pfp",
    name: "Pfp",
    description: "Random profile picture commands",
    count: 5,
    commands: [
      { id: "p1", name: "boys", description: "Random boy pfp" },
      { id: "p2", name: "girls", description: "Random girl pfp" },
      { id: "p3", name: "couples", description: "Random couple pfp" },
      { id: "p4", name: "anime", description: "Random anime pfp" },
      { id: "p5", name: "pic", description: "Random picture" },
    ],
  },
  {
    id: "voicemaster",
    name: "VoiceMaster",
    description: "Temporary auto-created voice channels",
    count: 2,
    commands: [
      { id: "vm1", name: "voicemaster setup", description: "Setup VoiceMaster" },
      { id: "vm2", name: "voicemaster remove", description: "Remove VoiceMaster" },
    ],
  },
  {
    id: "tickets",
    name: "Tickets",
    description: "Panel setup, transcripts, multi-type tickets & staff tools",
    count: 7,
    commands: [
      { id: "tk1", name: "ticket setup", description: "Setup ticket system" },
      { id: "tk2", name: "ticket config", description: "Configure tickets" },
      { id: "tk3", name: "ticket delete <id>", description: "Delete a ticket" },
      { id: "tk4", name: "open", description: "Open a ticket" },
      { id: "tk5", name: "close [reason]", description: "Close a ticket" },
      { id: "tk6", name: "rename <name>", description: "Rename a ticket" },
      { id: "tk7", name: "purgetickets", description: "Purge all tickets" },
    ],
  },
  {
    id: "botsettings",
    name: "BotSettings",
    description: "Profile, bio, banner, and badge management",
    count: 11,
    commands: [
      { id: "bs1", name: "profile [@user]", description: "View user profile" },
      { id: "bs2", name: "bio set", description: "Set your bio" },
      { id: "bs3", name: "bio clear", description: "Clear your bio" },
      { id: "bs4", name: "badge list", description: "List all badges" },
      { id: "bs5", name: "badge view [@user]", description: "View user badges" },
      { id: "bs6", name: "badge add @user <badge>", description: "Add badge to user" },
      { id: "bs7", name: "badge remove @user <badge>", description: "Remove badge from user" },
      { id: "bs8", name: "showbio", description: "Show your bio" },
      { id: "bs9", name: "changebio <text>", description: "Change your bio" },
      { id: "bs10", name: "showbanner", description: "Show your banner" },
      { id: "bs11", name: "changebanner <url>", description: "Change your banner" },
    ],
  },
  {
    id: "music",
    name: "Music",
    description: "Play music from YouTube, Spotify, SoundCloud & more",
    count: 34,
    commands: [
      { id: "mu1", name: "play <song/url>", description: "Play a song" },
      { id: "mu2", name: "search <query>", description: "Search for songs" },
      { id: "mu3", name: "nowplaying", description: "View current song" },
      { id: "mu4", name: "queue [page]", description: "View queue" },
      { id: "mu5", name: "skip", description: "Skip current song" },
      { id: "mu6", name: "pause", description: "Pause playback" },
      { id: "mu7", name: "resume", description: "Resume playback" },
      { id: "mu8", name: "volume <0-200>", description: "Set volume" },
      { id: "mu9", name: "seek <seconds>", description: "Seek to position" },
      { id: "mu10", name: "forward [seconds]", description: "Forward playback" },
      { id: "mu11", name: "rewind [seconds]", description: "Rewind playback" },
      { id: "mu12", name: "replay", description: "Replay current song" },
      { id: "mu13", name: "loop [none|song|queue]", description: "Set loop mode" },
      { id: "mu14", name: "shuffle", description: "Shuffle queue" },
      { id: "mu15", name: "clearqueue", description: "Clear queue" },
      { id: "mu16", name: "remove <#>", description: "Remove song from queue" },
      { id: "mu17", name: "move <from> <to>", description: "Move song in queue" },
      { id: "mu18", name: "skipinto <#>", description: "Skip to song number" },
      { id: "mu19", name: "autoplay", description: "Toggle autoplay" },
      { id: "mu20", name: "history", description: "View play history" },
      { id: "mu21", name: "247", description: "Toggle 24/7 mode" },
      { id: "mu22", name: "join", description: "Join voice channel" },
      { id: "mu23", name: "leave", description: "Leave voice channel" },
      { id: "mu24", name: "forcefix", description: "Force fix player" },
      { id: "mu25", name: "source", description: "View song source" },
      { id: "mu26", name: "filter [preset]", description: "Apply audio filter" },
      { id: "mu27", name: "filter reset", description: "Reset filters" },
      { id: "mu28", name: "filter toggle", description: "Toggle filter" },
      { id: "mu29", name: "lyrics [song]", description: "View song lyrics" },
      { id: "mu30", name: "platforms", description: "Supported platforms" },
      { id: "mu31", name: "savequeue [name]", description: "Save queue" },
      { id: "mu32", name: "loadqueue [name]", description: "Load saved queue" },
      { id: "mu33", name: "dj [@role]", description: "Set DJ role" },
      { id: "mu34", name: "volumeboost <0-500>", description: "Boost volume" },
    ],
  },
  {
    id: "premium",
    name: "Premium",
    description: "Premium features unlocked with a key",
    count: 4,
    commands: [
      { id: "pr1", name: "redeem <key>", description: "Redeem premium key" },
      { id: "pr2", name: "changepfp <url>", description: "Change bot profile picture" },
      { id: "pr3", name: "changebanner <url>", description: "Change bot banner" },
      { id: "pr4", name: "changebio <text>", description: "Change bot bio" },
    ],
  },
]

export function CommandSearch() {
  const [search, setSearch] = useState("")
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null)
  const [categories, setCategories] = useState<Category[]>(initialCategories)
  
  // Admin state
  const [showAdminModal, setShowAdminModal] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [password, setPassword] = useState("")
  const [passwordError, setPasswordError] = useState(false)
  
  // Edit state
  const [editingCommand, setEditingCommand] = useState<{ categoryId: string; commandId: string } | null>(null)
  const [editName, setEditName] = useState("")
  const [editDescription, setEditDescription] = useState("")
  const [addingToCategory, setAddingToCategory] = useState<string | null>(null)
  const [newCommandName, setNewCommandName] = useState("")
  const [newCommandDescription, setNewCommandDescription] = useState("")

  const filteredCategories = useMemo(() => {
    if (!search.trim()) return categories
    
    const searchLower = search.toLowerCase()
    return categories
      .map(category => ({
        ...category,
        commands: category.commands.filter(
          cmd => 
            cmd.name.toLowerCase().includes(searchLower) ||
            cmd.description.toLowerCase().includes(searchLower)
        ),
      }))
      .filter(category => category.commands.length > 0)
  }, [search, categories])

  const totalCommands = categories.reduce((sum, cat) => sum + cat.commands.length, 0)

  const handlePasswordSubmit = () => {
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true)
      setPasswordError(false)
      setPassword("")
    } else {
      setPasswordError(true)
    }
  }

  const handleEditCommand = (categoryId: string, command: Command) => {
    setEditingCommand({ categoryId, commandId: command.id })
    setEditName(command.name)
    setEditDescription(command.description)
  }

  const handleSaveEdit = () => {
    if (!editingCommand) return
    setCategories(prev => prev.map(cat => {
      if (cat.id === editingCommand.categoryId) {
        return {
          ...cat,
          commands: cat.commands.map(cmd => {
            if (cmd.id === editingCommand.commandId) {
              return { ...cmd, name: editName, description: editDescription }
            }
            return cmd
          }),
        }
      }
      return cat
    }))
    setEditingCommand(null)
  }

  const handleDeleteCommand = (categoryId: string, commandId: string) => {
    setCategories(prev => prev.map(cat => {
      if (cat.id === categoryId) {
        return {
          ...cat,
          commands: cat.commands.filter(cmd => cmd.id !== commandId),
          count: cat.count - 1,
        }
      }
      return cat
    }))
  }

  const handleAddCommand = (categoryId: string) => {
    if (!newCommandName.trim()) return
    const newId = `${categoryId}-${Date.now()}`
    setCategories(prev => prev.map(cat => {
      if (cat.id === categoryId) {
        return {
          ...cat,
          commands: [...cat.commands, { id: newId, name: newCommandName, description: newCommandDescription || "No description" }],
          count: cat.count + 1,
        }
      }
      return cat
    }))
    setNewCommandName("")
    setNewCommandDescription("")
    setAddingToCategory(null)
  }

  return (
    <section id="commands" className="relative px-6 py-24">
      <div className="mx-auto max-w-4xl">
        {/* Header */}
        <div className="mb-12 text-center">
          <div className="mb-3 flex items-center justify-center gap-2">
            <h2 className="text-2xl font-medium text-white">Commands</h2>
            <button 
              onClick={() => setShowAdminModal(true)}
              className="opacity-20 transition-opacity hover:opacity-40"
              aria-label="Admin"
            >
              <Lock className="h-3.5 w-3.5 text-white" />
            </button>
          </div>
          <p className="text-sm text-white/40">{totalCommands} commands across {categories.length} categories</p>
        </div>

        {/* Search */}
        <div className="relative mb-8">
          <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search commands..."
            className="w-full rounded-xl border border-white/10 bg-white/5 py-3.5 pl-11 pr-4 text-sm text-white placeholder:text-white/30 focus:border-white/20 focus:outline-none"
          />
        </div>

        {/* Categories */}
        <div className="space-y-2">
          {filteredCategories.map((category) => (
            <div key={category.id} className="rounded-xl border border-white/5 bg-white/[0.02]">
              <button
                onClick={() => setExpandedCategory(expandedCategory === category.id ? null : category.id)}
                className="flex w-full items-center justify-between px-5 py-4 text-left"
              >
                <div>
                  <span className="font-medium text-white">{category.name}</span>
                  <span className="ml-3 text-xs text-white/30">{category.commands.length} commands</span>
                </div>
                <ChevronDown 
                  className={`h-4 w-4 text-white/40 transition-transform ${
                    expandedCategory === category.id ? "rotate-180" : ""
                  }`} 
                />
              </button>
              
              {expandedCategory === category.id && (
                <div className="border-t border-white/5 px-5 pb-4 pt-2">
                  <p className="mb-4 text-xs text-white/40">{category.description}</p>
                  <div className="space-y-1">
                    {category.commands.map((command) => (
                      <div 
                        key={command.id} 
                        className="group flex items-center justify-between rounded-lg px-3 py-2 transition-colors hover:bg-white/5"
                      >
                        {editingCommand?.commandId === command.id && isAuthenticated ? (
                          <div className="flex flex-1 items-center gap-2">
                            <input
                              value={editName}
                              onChange={(e) => setEditName(e.target.value)}
                              className="w-32 rounded border border-white/10 bg-white/5 px-2 py-1 text-xs text-white"
                            />
                            <input
                              value={editDescription}
                              onChange={(e) => setEditDescription(e.target.value)}
                              className="flex-1 rounded border border-white/10 bg-white/5 px-2 py-1 text-xs text-white/60"
                            />
                            <button onClick={handleSaveEdit} className="text-green-400 hover:text-green-300">
                              <Check className="h-3.5 w-3.5" />
                            </button>
                            <button onClick={() => setEditingCommand(null)} className="text-white/40 hover:text-white/60">
                              <X className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        ) : (
                          <>
                            <div className="flex items-center gap-3">
                              <code className="rounded bg-white/5 px-2 py-0.5 text-xs text-white/80">+{command.name}</code>
                              <span className="text-xs text-white/40">{command.description}</span>
                            </div>
                            {isAuthenticated && (
                              <div className="flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                                <button 
                                  onClick={() => handleEditCommand(category.id, command)}
                                  className="p-1 text-white/30 hover:text-white/60"
                                >
                                  <Edit2 className="h-3 w-3" />
                                </button>
                                <button 
                                  onClick={() => handleDeleteCommand(category.id, command.id)}
                                  className="p-1 text-white/30 hover:text-red-400"
                                >
                                  <Trash2 className="h-3 w-3" />
                                </button>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    ))}
                    
                    {/* Add command form */}
                    {isAuthenticated && addingToCategory === category.id && (
                      <div className="mt-2 flex items-center gap-2 rounded-lg bg-white/5 p-2">
                        <input
                          value={newCommandName}
                          onChange={(e) => setNewCommandName(e.target.value)}
                          placeholder="Command name"
                          className="w-32 rounded border border-white/10 bg-white/5 px-2 py-1 text-xs text-white placeholder:text-white/30"
                        />
                        <input
                          value={newCommandDescription}
                          onChange={(e) => setNewCommandDescription(e.target.value)}
                          placeholder="Description"
                          className="flex-1 rounded border border-white/10 bg-white/5 px-2 py-1 text-xs text-white/60 placeholder:text-white/30"
                        />
                        <button 
                          onClick={() => handleAddCommand(category.id)}
                          className="rounded bg-white/10 px-2 py-1 text-xs text-white hover:bg-white/20"
                        >
                          Add
                        </button>
                        <button 
                          onClick={() => setAddingToCategory(null)}
                          className="text-white/40 hover:text-white/60"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    )}
                    
                    {isAuthenticated && addingToCategory !== category.id && (
                      <button
                        onClick={() => setAddingToCategory(category.id)}
                        className="mt-2 flex items-center gap-1 text-xs text-white/30 hover:text-white/50"
                      >
                        <Plus className="h-3 w-3" />
                        Add command
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {filteredCategories.length === 0 && (
          <p className="py-12 text-center text-sm text-white/40">No commands found for &quot;{search}&quot;</p>
        )}
      </div>

      {/* Admin Modal */}
      {showAdminModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl border border-white/10 bg-[#0a1628] p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-medium text-white">
                {isAuthenticated ? "Admin Mode Active" : "Admin Access"}
              </h3>
              <button 
                onClick={() => {
                  setShowAdminModal(false)
                  if (!isAuthenticated) setPassword("")
                }}
                className="text-white/40 hover:text-white/60"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            
            {isAuthenticated ? (
              <div className="space-y-4">
                <p className="text-sm text-white/50">
                  You can now edit, add, or delete commands. Changes are saved locally.
                </p>
                <button
                  onClick={() => {
                    setIsAuthenticated(false)
                    setShowAdminModal(false)
                  }}
                  className="w-full rounded-lg border border-white/10 py-2 text-sm text-white/70 hover:bg-white/5"
                >
                  Log Out
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value)
                      setPasswordError(false)
                    }}
                    onKeyDown={(e) => e.key === "Enter" && handlePasswordSubmit()}
                    placeholder="Enter password"
                    className={`w-full rounded-lg border bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-white/30 focus:outline-none ${
                      passwordError ? "border-red-500/50" : "border-white/10 focus:border-white/20"
                    }`}
                  />
                  {passwordError && (
                    <p className="mt-2 text-xs text-red-400">Incorrect password</p>
                  )}
                </div>
                <button
                  onClick={handlePasswordSubmit}
                  className="w-full rounded-lg bg-white py-2.5 text-sm font-medium text-[#040d18] hover:bg-white/90"
                >
                  Unlock
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  )
}
