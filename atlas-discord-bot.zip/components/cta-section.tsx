"use client"

import { ArrowRight, Sparkles } from "lucide-react"

export function CtaSection() {
  return (
    <section className="relative py-24 overflow-hidden">
      {/* Background decoration */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-96 w-96 rounded-full bg-blue-500/10 blur-3xl animate-pulse" style={{ animationDuration: "4s" }} />
      </div>

      <div className="relative z-10 mx-auto max-w-2xl px-6 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 mb-6">
          <Sparkles className="h-3 w-3 text-blue-400" />
          <span className="text-xs text-white/50">Free to use</span>
        </div>
        
        <h2 className="text-balance text-2xl font-semibold text-white sm:text-3xl">
          Ready to elevate your server?
        </h2>
        <p className="mt-4 text-white/40">
          Join thousands of communities already using Atlas.
        </p>
        <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <a
            href="#"
            className="group relative flex items-center gap-2 overflow-hidden rounded-full bg-white px-8 py-3.5 text-sm font-medium text-[#040d18] transition-all hover:shadow-[0_0_40px_rgba(255,255,255,0.2)]"
          >
            <span className="relative z-10 flex items-center gap-2">
              Get Started
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
            </span>
            <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-blue-200/30 to-transparent transition-transform duration-500 group-hover:translate-x-full" />
          </a>
          <a
            href="https://discord.gg/rMCjnRYtps"
            target="_blank"
            rel="noopener noreferrer"
            className="rounded-full border border-white/10 bg-white/5 px-6 py-3 text-sm text-white/60 transition-all hover:border-white/20 hover:bg-white/10 hover:text-white"
          >
            Contact Support
          </a>
        </div>
      </div>
    </section>
  )
}
