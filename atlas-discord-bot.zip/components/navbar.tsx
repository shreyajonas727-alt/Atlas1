"use client"

import { useState } from "react"
import Image from "next/image"
import { Menu, X, ChevronDown, Lock, LogOut, Edit3 } from "lucide-react"
import { useSite } from "@/lib/site-context"

const navLinks = [
  { key: "features", href: "#features" },
  { key: "commands", href: "#commands" },
  { key: "support", href: "https://discord.gg/rMCjnRYtps" },
  { key: "premium", href: "#premium" },
]

const languages = [
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "es", name: "Español", flag: "🇪🇸" },
  { code: "fr", name: "Français", flag: "🇫🇷" },
  { code: "de", name: "Deutsch", flag: "🇩🇪" },
  { code: "pt", name: "Português", flag: "🇧🇷" },
  { code: "ru", name: "Русский", flag: "🇷🇺" },
  { code: "ja", name: "日本語", flag: "🇯🇵" },
  { code: "ko", name: "한국어", flag: "🇰🇷" },
  { code: "zh", name: "中文", flag: "🇨🇳" },
  { code: "hi", name: "हिन्दी", flag: "🇮🇳" },
  { code: "ar", name: "العربية", flag: "🇸🇦" },
  { code: "tr", name: "Türkçe", flag: "🇹🇷" },
]

export function Navbar() {
  const { t, language, setLanguage, isAdmin, login, logout } = useSite()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [langDropdownOpen, setLangDropdownOpen] = useState(false)
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [password, setPassword] = useState("")
  const [loginError, setLoginError] = useState(false)

  const selectedLang = languages.find(l => l.code === language) || languages[0]

  const handleLogin = () => {
    if (login(password)) {
      setShowLoginModal(false)
      setPassword("")
      setLoginError(false)
    } else {
      setLoginError(true)
    }
  }

  return (
    <>
      <nav className="fixed top-0 z-50 w-full bg-[#040d18]/80 backdrop-blur-xl border-b border-white/5">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
          {/* Left side - Language selector */}
          <div className="relative">
            <button
              onClick={() => setLangDropdownOpen(!langDropdownOpen)}
              className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-sm transition-all hover:bg-white/10 hover:border-white/20"
            >
              <span className="text-base">{selectedLang.flag}</span>
              <span className="hidden text-white/70 sm:inline">{selectedLang.code.toUpperCase()}</span>
              <ChevronDown className={`h-3 w-3 text-white/40 transition-transform duration-300 ${langDropdownOpen ? "rotate-180" : ""}`} />
            </button>
            
            {langDropdownOpen && (
              <>
                <div className="fixed inset-0" onClick={() => setLangDropdownOpen(false)} />
                <div className="absolute left-0 top-full mt-2 w-48 rounded-xl border border-white/10 bg-[#0a1628]/95 backdrop-blur-xl p-2 shadow-2xl animate-in fade-in slide-in-from-top-2 duration-200">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLanguage(lang.code)
                        setLangDropdownOpen(false)
                      }}
                      className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-all hover:bg-white/10 ${
                        language === lang.code ? "bg-blue-500/20 text-white" : "text-white/60"
                      }`}
                    >
                      <span className="text-lg">{lang.flag}</span>
                      <span>{lang.name}</span>
                      {language === lang.code && (
                        <div className="ml-auto h-1.5 w-1.5 rounded-full bg-blue-400" />
                      )}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Center - Logo with bot avatar */}
          <a href="/" className="absolute left-1/2 flex -translate-x-1/2 items-center gap-3 group">
            <div className="relative">
              <Image
                src="/images/atlas-avatar.png"
                alt="Atlas"
                width={36}
                height={36}
                className="rounded-full ring-2 ring-white/10 transition-all group-hover:ring-blue-500/50"
              />
              <div className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-[#040d18] bg-green-500 animate-pulse" />
            </div>
            <span className="text-lg font-semibold tracking-tight text-white">Atlas</span>
          </a>

          {/* Right side - Nav links */}
          <div className="hidden items-center gap-6 md:flex">
            {navLinks.map((link) => (
              <a
                key={link.key}
                href={link.href}
                target={link.href.startsWith("http") ? "_blank" : undefined}
                rel={link.href.startsWith("http") ? "noopener noreferrer" : undefined}
                className="text-sm text-white/50 transition-all hover:text-white relative group"
              >
                {t(link.key)}
                <span className="absolute -bottom-1 left-0 h-px w-0 bg-white transition-all group-hover:w-full" />
              </a>
            ))}
            <a
              href="#"
              className="group relative overflow-hidden rounded-full bg-white px-5 py-2 text-sm font-medium text-[#040d18] transition-all hover:shadow-[0_0_30px_rgba(255,255,255,0.3)]"
            >
              <span className="relative z-10">{t("addToDiscord")}</span>
              <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-blue-500/20 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
            </a>
          </div>

          <button
            className="text-white/60 md:hidden transition-colors hover:text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {/* Admin indicator */}
        {isAdmin && (
          <div className="absolute top-full left-0 right-0 bg-blue-500/10 border-b border-blue-500/20 px-4 py-1.5">
            <div className="mx-auto max-w-6xl flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs text-blue-400">
                <Edit3 className="h-3 w-3" />
                <span>Admin Mode - Click on elements to edit</span>
              </div>
              <button
                onClick={logout}
                className="flex items-center gap-1.5 text-xs text-blue-400 hover:text-blue-300 transition-colors"
              >
                <LogOut className="h-3 w-3" />
                Logout
              </button>
            </div>
          </div>
        )}

        {mobileMenuOpen && (
          <div className="border-t border-white/5 bg-[#040d18]/95 backdrop-blur-xl px-6 py-6 md:hidden animate-in slide-in-from-top-2 duration-200">
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <a
                  key={link.key}
                  href={link.href}
                  target={link.href.startsWith("http") ? "_blank" : undefined}
                  rel={link.href.startsWith("http") ? "noopener noreferrer" : undefined}
                  className="text-sm text-white/60 transition-colors hover:text-white"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {t(link.key)}
                </a>
              ))}
              <a
                href="#"
                className="mt-2 rounded-full bg-white py-2.5 text-center text-sm font-medium text-[#040d18]"
              >
                {t("addToDiscord")}
              </a>
            </div>
          </div>
        )}
      </nav>

      {/* Floating admin lock button */}
      <button
        onClick={() => isAdmin ? logout() : setShowLoginModal(true)}
        className={`fixed bottom-6 right-6 z-50 p-3 rounded-full transition-all duration-300 ${
          isAdmin 
            ? "bg-blue-500/20 border border-blue-500/30 text-blue-400 hover:bg-blue-500/30" 
            : "bg-white/5 border border-white/10 text-white/20 hover:text-white/40 hover:bg-white/10"
        }`}
        title={isAdmin ? "Logout" : "Admin Login"}
      >
        {isAdmin ? <LogOut className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
      </button>

      {/* Login Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-sm mx-4 rounded-2xl border border-white/10 bg-[#0a1628] p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <button
              onClick={() => {
                setShowLoginModal(false)
                setPassword("")
                setLoginError(false)
              }}
              className="absolute right-4 top-4 text-white/40 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
            
            <div className="text-center mb-6">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-white/5 mb-4">
                <Lock className="h-5 w-5 text-white/60" />
              </div>
              <h3 className="text-lg font-semibold text-white">Admin Access</h3>
              <p className="text-sm text-white/40 mt-1">Enter password to edit website content</p>
            </div>

            <input
              type="password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value)
                setLoginError(false)
              }}
              onKeyDown={(e) => e.key === "Enter" && handleLogin()}
              placeholder="Enter password..."
              className={`w-full rounded-xl border bg-white/5 px-4 py-3 text-sm text-white placeholder-white/30 outline-none transition-all ${
                loginError ? "border-red-500/50 shake" : "border-white/10 focus:border-blue-500/50"
              }`}
              autoFocus
            />
            
            {loginError && (
              <p className="mt-2 text-xs text-red-400 animate-in fade-in duration-200">Incorrect password</p>
            )}

            <button
              onClick={handleLogin}
              className="mt-4 w-full rounded-xl bg-white py-3 text-sm font-medium text-[#040d18] transition-all hover:bg-white/90"
            >
              Login
            </button>
          </div>
        </div>
      )}

      <style jsx>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-5px); }
          75% { transform: translateX(5px); }
        }
        .shake {
          animation: shake 0.3s ease-in-out;
        }
      `}</style>
    </>
  )
}
