"use client"

import { useState, useEffect } from "react"
import { Terminal, CheckCircle2 } from "lucide-react"

const commandShowcase = [
  { cmd: "+antinuke enable", response: "Anti-nuke protection enabled", delay: 0 },
  { cmd: "+ticket setup", response: "Ticket system configured", delay: 2000 },
  { cmd: "+logging setup auto", response: "Auto-logging enabled for all events", delay: 4000 },
  { cmd: "+automod enable", response: "AutoMod protection activated", delay: 6000 },
]

export function ShowcaseSection() {
  const [activeCommand, setActiveCommand] = useState(0)
  const [typing, setTyping] = useState(true)

  useEffect(() => {
    const interval = setInterval(() => {
      setTyping(true)
      setTimeout(() => {
        setTyping(false)
        setActiveCommand((prev) => (prev + 1) % commandShowcase.length)
      }, 1000)
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  return (
    <section className="relative py-24 overflow-hidden">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-0 h-px w-1/2 bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      </div>

      <div className="mx-auto max-w-4xl px-6">
        <div className="mb-16 text-center">
          <p className="text-sm font-medium uppercase tracking-wider text-blue-400/60">Live Preview</p>
          <h2 className="mt-2 text-balance text-3xl font-semibold text-white sm:text-4xl">
            See Atlas in action
          </h2>
        </div>

        <div className="rounded-2xl border border-white/10 bg-[#0a1220] overflow-hidden max-w-2xl mx-auto">
          <div className="flex items-center gap-2 border-b border-white/5 bg-white/[0.02] px-4 py-3">
            <div className="flex gap-1.5">
              <div className="h-3 w-3 rounded-full bg-red-500/60" />
              <div className="h-3 w-3 rounded-full bg-yellow-500/60" />
              <div className="h-3 w-3 rounded-full bg-green-500/60" />
            </div>
            <span className="ml-2 text-xs text-white/30">Discord Console</span>
          </div>
          
          <div className="p-6 font-mono text-sm space-y-4 min-h-[220px]">
            {commandShowcase.slice(0, activeCommand + 1).map((item, index) => (
              <div key={index} className="animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="flex items-center gap-2 text-white/70">
                  <Terminal className="h-3.5 w-3.5 text-blue-400" />
                  <span>{item.cmd}</span>
                  {index === activeCommand && typing && (
                    <span className="animate-pulse">|</span>
                  )}
                </div>
                {(index < activeCommand || !typing) && (
                  <div className="ml-5 mt-1.5 flex items-center gap-2 text-green-400/80 animate-in fade-in duration-200">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    <span>{item.response}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
