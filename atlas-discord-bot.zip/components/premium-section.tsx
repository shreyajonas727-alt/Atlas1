"use client"

import Image from "next/image"
import { Crown, Zap, Gift, CreditCard, Check } from "lucide-react"

const pricingPlans = [
  { duration: "1 Month", inr: "99", ltc: "1", badge: "Budget Friendly" },
  { duration: "3 Months", inr: "299", ltc: "2", badge: "Most Popular", popular: true },
  { duration: "6 Months", inr: "399", ltc: "4", badge: null },
  { duration: "1 Year", inr: "599", ltc: "6", badge: "Best Yearly Deal" },
  { duration: "Lifetime", inr: "999", ltc: "10", badge: "Unbeatable Value" },
]

const premiumFeatures = [
  "Use commands without prefix",
  "Priority support response",
  "Access across all servers",
  "Exclusive premium commands",
  "Custom bot settings",
]

export function PremiumSection() {
  return (
    <section id="premium" className="relative py-24 overflow-hidden">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/4 top-1/2 h-96 w-96 -translate-y-1/2 rounded-full bg-blue-500/5 blur-3xl" />
        <div className="absolute right-1/4 top-1/3 h-64 w-64 rounded-full bg-yellow-500/5 blur-3xl" />
      </div>

      <div className="mx-auto max-w-6xl px-6 relative">
        <div className="mb-16 text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-yellow-500/20 bg-yellow-500/10 px-4 py-1.5 mb-4">
            <Crown className="h-4 w-4 text-yellow-500" />
            <span className="text-sm font-medium text-yellow-500">Premium Access</span>
          </div>
          <h2 className="text-balance text-3xl font-semibold text-white sm:text-4xl">
            Unlock the full potential
          </h2>
          <p className="mt-4 text-white/50 max-w-xl mx-auto">
            With Premium Access, use bot commands instantly and naturally without typing any prefixes. 
            Faster, cleaner, and more advanced than ever.
          </p>
        </div>

        {/* Special offer banner */}
        <div className="mb-12 rounded-2xl border border-yellow-500/20 bg-gradient-to-r from-yellow-500/10 via-yellow-500/5 to-transparent p-6 max-w-2xl mx-auto">
          <div className="flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-yellow-500/20">
              <Gift className="h-6 w-6 text-yellow-500" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-white">Special Launch Offer</p>
              <p className="text-sm text-white/50">
                Get Lifetime Premium for just <span className="text-yellow-500 font-medium">Rs899 / 5$ LTC</span> - Limited to first 5 users!
              </p>
            </div>
            <Zap className="h-5 w-5 text-yellow-500 animate-pulse" />
          </div>
        </div>

        {/* Pricing grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5 mb-12">
          {pricingPlans.map((plan) => (
            <div
              key={plan.duration}
              className={`rounded-xl border p-5 transition-all duration-300 hover:scale-105 ${
                plan.popular 
                  ? "border-blue-500/30 bg-blue-500/10" 
                  : "border-white/10 bg-white/[0.02] hover:border-white/20"
              }`}
            >
              {plan.badge && (
                <span className={`inline-block text-xs font-medium px-2 py-0.5 rounded-full mb-3 ${
                  plan.popular ? "bg-blue-500/20 text-blue-400" : "bg-white/10 text-white/60"
                }`}>
                  {plan.badge}
                </span>
              )}
              <p className="font-semibold text-white">{plan.duration}</p>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-2xl font-bold text-white">Rs{plan.inr}</span>
                <span className="text-white/40 text-sm">/ {plan.ltc}$ LTC</span>
              </div>
            </div>
          ))}
        </div>

        {/* Features */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-8 max-w-xl mx-auto">
          <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-blue-400" />
            What you get
          </h3>
          <ul className="space-y-3">
            {premiumFeatures.map((feature) => (
              <li key={feature} className="flex items-center gap-3 text-white/70">
                <Check className="h-4 w-4 text-green-500" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
          <div className="mt-6 pt-6 border-t border-white/10">
            <p className="text-xs text-white/40 text-center">
              Purchase via INR or LTC. Your account instantly unlocks Premium Access across all servers.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
