"use client"

import Image from "next/image"
import { Code2, Heart } from "lucide-react"

const developers = [
  {
    name: "0f19",
    role: "Main Developer",
    avatar: "/images/owner-avatar.png",
    badge: "Owner",
  },
  {
    name: "k78u",
    role: "Co-Developer",
    avatar: "/images/co-owner-avatar.png",
    badge: "Co-Owner",
  },
]

export function DevelopersSection() {
  return (
    <section className="relative py-24 overflow-hidden">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-0 h-px w-1/2 bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      </div>

      <div className="mx-auto max-w-4xl px-6 relative">
        <div className="mb-16 text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 mb-4">
            <Code2 className="h-4 w-4 text-blue-400" />
            <span className="text-sm font-medium text-white/70">Meet the Team</span>
          </div>
          <h2 className="text-balance text-3xl font-semibold text-white sm:text-4xl">
            The developers behind Atlas
          </h2>
          <p className="mt-4 text-white/50 max-w-lg mx-auto">
            Built with passion by a dedicated team focused on creating the best Discord experience.
          </p>
        </div>

        <div className="grid gap-8 sm:grid-cols-2 max-w-2xl mx-auto">
          {developers.map((dev) => (
            <div
              key={dev.name}
              className="group rounded-2xl border border-white/10 bg-white/[0.02] p-6 text-center transition-all duration-300 hover:border-white/20 hover:bg-white/[0.04]"
            >
              <div className="relative mx-auto mb-4 h-24 w-24">
                <div className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <Image
                  src={dev.avatar}
                  alt={dev.name}
                  width={96}
                  height={96}
                  className="rounded-full border-2 border-white/10 object-cover"
                />
                <div className="absolute -bottom-1 -right-1 rounded-full bg-[#040d18] px-2 py-0.5 border border-white/20">
                  <span className="text-xs font-medium text-blue-400">{dev.badge}</span>
                </div>
              </div>
              <h3 className="text-lg font-semibold text-white">{dev.name}</h3>
              <p className="text-sm text-white/50">{dev.role}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="inline-flex items-center gap-2 text-sm text-white/40">
            <Heart className="h-4 w-4 text-red-400" />
            Thank you for supporting Atlas
          </p>
        </div>
      </div>
    </section>
  )
}
