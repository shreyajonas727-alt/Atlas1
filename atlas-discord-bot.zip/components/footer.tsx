import Image from "next/image"

export function Footer() {
  return (
    <footer className="relative border-t border-white/5 py-12 overflow-hidden">
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-blue-500/5 to-transparent" />
      
      <div className="relative z-10 mx-auto max-w-5xl px-6">
        <div className="flex flex-col items-center justify-between gap-6 sm:flex-row">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <Image
              src="/images/atlas-avatar.png"
              alt="Atlas"
              width={24}
              height={24}
              className="rounded-full"
            />
            <span className="text-sm font-medium text-white/70">Atlas</span>
          </div>

          <div className="flex items-center gap-6">
            <a href="#features" className="text-sm text-white/40 transition-colors hover:text-white/70">
              Features
            </a>
            <a href="#commands" className="text-sm text-white/40 transition-colors hover:text-white/70">
              Commands
            </a>
            <a
              href="https://discord.gg/rMCjnRYtps"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-white/40 transition-colors hover:text-white/70"
            >
              Support
            </a>
            <a href="#premium" className="text-sm text-white/40 transition-colors hover:text-white/70">
              Premium
            </a>
          </div>

          <p className="text-sm text-white/30">
            © {new Date().getFullYear()} Atlas Development
          </p>
        </div>
      </div>
    </footer>
  )
}
