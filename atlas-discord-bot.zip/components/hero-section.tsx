"use client"

import { ArrowRight, Sparkles } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 pt-16">
      {/* Animated background elements */}
      <div className="pointer-events-none absolute inset-0">
        {/* Subtle gradient */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(59,130,246,0.08)_0%,_transparent_60%)]" />
        
        {/* Floating orbs */}
        <div className="absolute left-1/4 top-1/4 h-64 w-64 rounded-full bg-blue-500/5 blur-3xl animate-pulse" style={{ animationDuration: "4s" }} />
        <div className="absolute right-1/4 bottom-1/4 h-96 w-96 rounded-full bg-blue-600/5 blur-3xl animate-pulse" style={{ animationDuration: "6s", animationDelay: "1s" }} />
        
        {/* Grid pattern */}
        <div 
          className="absolute inset-0 opacity-[0.02]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: "60px 60px",
          }}
        />
      </div>
      
      <div className="relative z-10 mx-auto max-w-3xl text-center">
        {/* Badge with animation */}
        <div className="mb-8 inline-flex animate-in fade-in slide-in-from-bottom-4 duration-700 items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 backdrop-blur-sm">
          <Sparkles className="h-3 w-3 text-blue-400" />
          <span className="text-xs text-white/50">Developed by Atlas Development</span>
        </div>

        {/* Title with stagger animation */}
        <h1 className="animate-in fade-in slide-in-from-bottom-6 duration-700 delay-100 text-balance text-5xl font-semibold tracking-tight text-white sm:text-6xl lg:text-7xl">
          Atlas
        </h1>
        
        <p className="mt-4 animate-in fade-in slide-in-from-bottom-6 duration-700 delay-200 text-lg text-white/40 sm:text-xl">
          Discord Management, Security & Music
        </p>

        <p className="mx-auto mt-6 max-w-xl animate-in fade-in slide-in-from-bottom-6 duration-700 delay-300 text-pretty text-base leading-relaxed text-white/50">
          Advanced moderation, anti-nuke protection, automation, logging, 
          tickets, and premium music for your community.
        </p>

        {/* CTAs with animation */}
        <div className="mt-10 flex animate-in fade-in slide-in-from-bottom-6 duration-700 delay-400 flex-col items-center justify-center gap-4 sm:flex-row">
          <a
            href="#"
            className="group relative flex items-center gap-2 overflow-hidden rounded-full bg-white px-6 py-3 text-sm font-medium text-[#040d18] transition-all hover:shadow-[0_0_40px_rgba(255,255,255,0.2)]"
          >
            <span className="relative z-10 flex items-center gap-2">
              Add Atlas
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
            </span>
            <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-500 group-hover:translate-x-full" />
          </a>
          
          <a
            href="https://discord.gg/rMCjnRYtps"
            target="_blank"
            rel="noopener noreferrer"
            className="group flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-6 py-3 text-sm font-medium text-white backdrop-blur-sm transition-all hover:border-white/20 hover:bg-white/10"
          >
            Join Support
          </a>
        </div>

        {/* Secondary links */}
        <div className="mt-8 flex animate-in fade-in slide-in-from-bottom-6 duration-700 delay-500 items-center justify-center gap-6">
          <a href="#" className="text-sm text-white/40 transition-colors hover:text-white/70">
            Documentation
          </a>
          <span className="text-white/20">|</span>
          <a href="#" className="text-sm text-white/40 transition-colors hover:text-white/70">
            Premium
          </a>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce" style={{ animationDuration: "2s" }}>
          <div className="flex flex-col items-center gap-2">
            <span className="text-xs text-white/30">Scroll</span>
            <div className="h-6 w-4 rounded-full border border-white/20 p-1">
              <div className="h-1.5 w-1.5 rounded-full bg-white/40 animate-pulse" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
