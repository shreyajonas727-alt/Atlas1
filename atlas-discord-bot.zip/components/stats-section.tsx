"use client"

import { Server, Users, Zap, Shield } from "lucide-react"

const stats = [
  { icon: Server, value: "50+", label: "Servers" },
  { icon: Users, value: "6,000+", label: "Users" },
  { icon: Zap, value: "200+", label: "Commands" },
  { icon: Shield, value: "24/7", label: "Online" },
]

export function StatsSection() {
  return (
    <section className="relative py-16 overflow-hidden">
      <div className="mx-auto max-w-5xl px-6">
        <div className="rounded-2xl border border-white/5 bg-white/[0.02] p-8 backdrop-blur-sm">
          <div className="grid grid-cols-2 gap-8 lg:grid-cols-4">
            {stats.map((stat, index) => (
              <div 
                key={index} 
                className="group flex flex-col items-center text-center"
              >
                <div className="mb-3 rounded-xl bg-white/5 p-3 transition-all duration-300 group-hover:bg-blue-500/10 group-hover:scale-110">
                  <stat.icon className="h-5 w-5 text-white/40 transition-colors group-hover:text-blue-400" />
                </div>
                <span className="text-3xl font-semibold text-white sm:text-4xl">{stat.value}</span>
                <span className="mt-1 text-sm text-white/40">{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
