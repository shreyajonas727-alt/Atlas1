"use client"

import { Shield, Settings, Music, Ticket, FileText, Sparkles } from "lucide-react"

const features = [
  {
    icon: Shield,
    title: "Security",
    description: "Anti-nuke and anti-raid protection to keep your server safe.",
  },
  {
    icon: Settings,
    title: "Moderation",
    description: "Powerful auto-mod and warning systems for easy management.",
  },
  {
    icon: Music,
    title: "Music",
    description: "High-quality playback with advanced queue controls.",
  },
  {
    icon: Ticket,
    title: "Tickets",
    description: "Professional support system with custom categories.",
  },
  {
    icon: FileText,
    title: "Logging",
    description: "Track every action with comprehensive audit logs.",
  },
  {
    icon: Sparkles,
    title: "Automation",
    description: "Welcome messages, auto-roles, and custom commands.",
  },
]

export function FeaturesSection() {
  return (
    <section id="features" className="relative py-24 overflow-hidden">
      {/* Background decoration */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute right-0 top-1/4 h-96 w-96 rounded-full bg-blue-500/5 blur-3xl" />
        <div className="absolute left-0 bottom-1/4 h-64 w-64 rounded-full bg-blue-600/5 blur-3xl" />
      </div>

      <div className="relative z-10 mx-auto max-w-5xl px-6">
        <div className="mb-16 text-center">
          <p className="text-sm font-medium uppercase tracking-wider text-blue-400/60">Features</p>
          <h2 className="mt-2 text-balance text-3xl font-semibold text-white sm:text-4xl">
            Everything you need
          </h2>
          <p className="mt-4 text-white/40">Powerful tools to manage and protect your community</p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group relative rounded-2xl border border-white/5 bg-white/[0.02] p-6 transition-all duration-300 hover:border-white/10 hover:bg-white/[0.04]"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              {/* Hover glow effect */}
              <div className="pointer-events-none absolute inset-0 rounded-2xl opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-blue-500/10 via-transparent to-transparent" />
              </div>
              
              <div className="relative z-10">
                <div className="mb-4 inline-flex rounded-xl bg-white/5 p-3 transition-colors group-hover:bg-white/10">
                  <feature.icon className="h-5 w-5 text-white/50 transition-colors group-hover:text-blue-400" />
                </div>
                <h3 className="font-medium text-white">{feature.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-white/40">
                  {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
