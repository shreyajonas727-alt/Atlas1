import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { StatsSection } from "@/components/stats-section"
import { ShowcaseSection } from "@/components/showcase-section"
import { FeaturesSection } from "@/components/features-section"
import { CommandSearch } from "@/components/command-search"
import { PremiumSection } from "@/components/premium-section"
import { DevelopersSection } from "@/components/developers-section"
import { CtaSection } from "@/components/cta-section"
import { Footer } from "@/components/footer"

export default function Page() {
  return (
    <main className="min-h-screen bg-[#040d18]">
      <Navbar />
      <HeroSection />
      <StatsSection />
      <ShowcaseSection />
      <FeaturesSection />
      <CommandSearch />
      <PremiumSection />
      <DevelopersSection />
      <CtaSection />
      <Footer />
    </main>
  )
}
